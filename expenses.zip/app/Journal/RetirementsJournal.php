<?php

namespace App\Journal;

use Illuminate\Database\Eloquent\Model;

class RetirementsJournal extends Model
{
    //
}
