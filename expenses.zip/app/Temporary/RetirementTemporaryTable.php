<?php

namespace App\Temporary;

use Illuminate\Database\Eloquent\Model;

class RetirementTemporaryTable extends Model
{
    //
}
