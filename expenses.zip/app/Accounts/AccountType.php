<?php

namespace App\Accounts;

use Illuminate\Database\Eloquent\Model;

class AccountType extends Model
{
    //
}
