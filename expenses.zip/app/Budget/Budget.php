<?php

namespace App\Budget;

use Illuminate\Database\Eloquent\Model;

class Budget extends Model
{
    protected $fillable = [
    	'title_no',
    	'title',
    ];
}
