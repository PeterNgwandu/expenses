<?php

namespace App\Comments;

use Illuminate\Database\Eloquent\Model;

class ExpenseRetirementComment extends Model
{
    //
}
