<?php

namespace App\Http\Controllers\Journal;

use DB;
use PDF;
use App\Journal\Journal;
use App\Journal\RetirementsJournal;
use Illuminate\Http\Request;
use App\Retirement\Retirement;
use App\Requisition\Requisition;
use App\Http\Controllers\Controller;
use App\Accounts\FinanceSupportiveDetail;

class JournalController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        // $requisitions = DB::table('finance_supportive_details')->join('requisitions','finance_supportive_details.req_no','requisitions.req_no')->join('users','requisitions.user_id','users.id')->join('sub_account_types','users.sub_acc_type_id','sub_account_types.id')->join('accounts','requisitions.account_id','accounts.id')->select(DB::raw("SUM(finance_supportive_details.amount_paid) as amount_paid"),'requisitions.req_no','requisitions.activity_name','users.username as username','users.account_no as account_no')->groupBy('requisitions.id')->groupBy('requisitions.user_id')->groupBy('requisitions.account_id')->groupBy('requisitions.req_no')->distinct('requisitions.req_no')->get();

        $requisitions = DB::table('requisitions')->join('finance_supportive_details','requisitions.req_no','finance_supportive_details.req_no')
                                                 ->join('users','requisitions.user_id','users.id')
                                                 ->join('accounts','requisitions.account_id','accounts.id')
                                                 ->select(DB::raw("SUM(finance_supportive_details.amount_paid) as amount_paid"),'requisitions.*','users.username as username','users.account_no as account_no','accounts.account_name as account')
                                                 ->where('requisitions.status', 'Paid')
                                                 ->groupBy('requisitions.id')
                                                 ->distinct('req_no')
                                                 ->get();

        // $retirements = DB::table('retirements')->join('requisitions','retirements.req_no','requisitions.req_no')->join('users','requisitions.user_id','users.id')->join('accounts','requisitions.account_id','accounts.id')->select(DB::raw("SUM((retirements.quantity * retirements.unit_price) * 1.18) as amount_paid"),DB::raw("SUM(retirements.vat_amount) as vat"),'requisitions.req_no','users.username as username','accounts.account_name as account')->groupBy('requisitions.id')->distinct('req_no')->get();

        // $retirements = DB::table('retirements')->join('requisitions','retirements.req_no','requisitions.req_no')->join('users','retirements.user_id','users.id')->join('sub_account_types','users.sub_acc_type_id','sub_account_types.id')->join('accounts','retirements.account_id','accounts.id')->select('retirements.created_at','retirements.ret_no','retirements.supplier_id','retirements.item_name','retirements.description','users.username as username','users.account_no as account_no','accounts.account_name as account', DB::raw("SUM((requisitions.quantity * requisitions.unit_price) * 1.18) as amount_paid"),DB::raw("SUM(retirements.vat_amount) as vat"))->where('retirements.status','Confirmed')->groupBy('retirements.id')->distinct()->get();

        $retirements = Retirement::join('users','retirements.user_id','users.id')
                                   ->join('accounts','retirements.account_id','accounts.id')
                                   ->join('requisitions','retirements.req_no','requisitions.req_no')
                                   ->select(DB::raw("SUM(retirements.gross_amount)as total"),'retirements.*','users.username as staff','users.account_no as Account_No','accounts.account_name as Account_Name','requisitions.req_no')
                                   ->where('retirements.status', 'Confirmed')
                                   ->groupBy('retirements.id')
                                   ->distinct('retirements.ret_no')
                                   ->get();



        return view('journals.create-journal')->withRequisitions($requisitions)->withRetirements($retirements);
    }

    public static function getDebitTotal($req_no)
    {
        
        $net = FinanceSupportiveDetail::join('requisitions','finance_supportive_details.req_no','requisitions.req_no')
               ->where('finance_supportive_details.req_no',$req_no)
               ->sum('amount_paid');
        return $net;
    }

    public static function getCreditTotal($req_no)
    {
        
        $net = FinanceSupportiveDetail::join('requisitions','finance_supportive_details.req_no','requisitions.req_no')
               ->where('finance_supportive_details.req_no',$req_no)
               ->sum('amount_paid');
        return -($net);
    }

    public static function getNetTotal($req_no)
    {
        $net = JournalController::getDebitTotal($req_no) + JournalController::getCreditTotal($req_no);
        return $net;
    }

    public function printJournal(Request $request)
    {
        $requisitions = DB::table('requisitions')->join('finance_supportive_details','requisitions.req_no','finance_supportive_details.req_no')->join('users','requisitions.user_id','users.id')->join('accounts','requisitions.account_id','accounts.id')->select(DB::raw("SUM(finance_supportive_details.amount_paid) as amount_paid"),'requisitions.*','users.username as username','users.account_no as account_no','accounts.account_name as account')->groupBy('requisitions.id')->distinct('req_no')->get();

        $retirements = Retirement::join('users','retirements.user_id','users.id')
        ->join('accounts','retirements.account_id','accounts.id')
        ->join('requisitions','retirements.req_no','requisitions.req_no')
        ->select(DB::raw("SUM(retirements.gross_amount)as total"),'retirements.*','users.username as staff','users.account_no as Account_No','accounts.account_name as Account_Name','requisitions.req_no')
        ->groupBy('retirements.id')
        ->distinct('retirements.ret_no')
        ->get();

        $pdf = PDF::loadView('journals.journal-pdf', compact('requisitions','retirements'));
        return $pdf->stream('journal-pdf');
    }

    public static function postJournal(Request $request)
    {
        $requisitions = DB::table('requisitions')->join('finance_supportive_details','requisitions.req_no','finance_supportive_details.req_no')->join('users','requisitions.user_id','users.id')->join('accounts','requisitions.account_id','accounts.id')->select(DB::raw("SUM(finance_supportive_details.amount_paid) as amount_paid"),'requisitions.*','users.username as username','users.account_no as account_no','accounts.account_name as account')->groupBy('requisitions.id')->distinct('req_no')->get();

        $retirements = Retirement::join('users','retirements.user_id','users.id')
        ->join('accounts','retirements.account_id','accounts.id')
        ->join('requisitions','retirements.req_no','requisitions.req_no')
        ->select(DB::raw("SUM(retirements.gross_amount)as total"),'retirements.*','users.username as staff','users.account_no as Account_No','accounts.account_name as Account_Name','requisitions.req_no')
        ->groupBy('retirements.id')
        ->distinct('retirements.ret_no')
        ->get();

        $finance_supportive_details = DB::table('finance_supportive_details')->where('finance_supportive_details.status', 'Not Posted')->get();

        foreach ($requisitions as $requisition) {
            $journal = new Journal();
            $journal->journal_no = $request->journal_no;
            $journal->req_no = $requisition->req_no;
            $journal->status = 'Posted';
            $journal->save();
        }
        
        foreach ($retirements as $retirement) {
            $journal = new RetirementsJournal();
            $journal->journal_no = $request->journal_no;  
            $journal->ret_no = $retirement->ret_no;
            $journal->req_no = $retirement->req_no;
            $journal->status = 'Posted';
            $journal->save();
        }

        foreach ($finance_supportive_details as $payment) {
            $finance_supportive_detail = new FinanceSupportiveDetail();
            $finance_supportive_detail->where('finance_supportive_details.status', 'Not Posted')->update([
                'status' => 'Posted',
            ]);
        }

        alert()->success('Journal Posted Successfuly', 'Good Job')->persistent('close');
        return redirect()->back();              
    }

    public static function generateJournalNo()
    {
        if (Journal::count() == 0) {
            $journal_no = "JE-1";
        }elseif (Journal::count() != 0) {
            $count = JournalController::getJournalCount();
            $journal_no = "JE-" . ($count + 1);
        }
        return $journal_no;
    }

    public static function getJournalCount()
    {
        return Journal::distinct('journal_no')->count('journal_no');
    }

    public static function getTotalofPaidRequisitions()
    {
        return FinanceSupportiveDetail::join('requisitions','finance_supportive_details.req_no','requisitions.req_no')
                                        ->where('finance_supportive_details.status','!=', 'Posted')
                                        ->where('requisitions.status', 'Paid')
                                        ->sum('amount_paid');
    }

    public static function getTotalofRetiredRequisitions()
    {
        return Retirement::where('status','Confirmed')->sum('gross_amount'); 
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
