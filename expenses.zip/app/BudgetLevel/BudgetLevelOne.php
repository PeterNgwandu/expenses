<?php

namespace App\BudgetLevel;

use Illuminate\Database\Eloquent\Model;

class BudgetLevelOne extends Model
{
    protected $fillable = [
        'title',
    ];
}
