# expenses-ms
FastPay Expenses Management System
