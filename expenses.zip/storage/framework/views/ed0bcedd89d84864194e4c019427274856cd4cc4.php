<?php

use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Dashboard\DashboardController;
use App\Http\Controllers\Requisitions\RequisitionsController;

?>


<?php $__env->startSection('content'); ?>

<div class="preload">
    <img class="img" src="<?php echo e(url('assets/images/giphy.gif')); ?>">
</div>
<div class="mdk-drawer-layout js-mdk-drawer-layout mydata" data-fullbleed data-push data-has-scrolling-region>
    <div class="mdk-drawer-layout__content mdk-header-layout__content--scrollable" style="margin-top: 30px">
		<h3 class="lead bold" style="margin-left: 78px;">My Dashboard</h3>
    	<div class="card-deck ml-5 mr-5">
                        <div class="card p-2 pl-3 pr-3">

                            <div class="media justify-items-center align-items-center h-md-100">
                                <i class="material-icons md-48 text-link-color">folder</i>
                                <div class="media-body pl-2">
                                    <h3 class="mb-0 text"><?php echo e(DashboardController::getAllRequisitionCount(Auth::user()->id)); ?></h3>
                                    <span>Total Requisitions</span>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                        <div class="card p-2 pl-3 pr-3">

                            <div class="media justify-items-center align-items-center h-md-100">
                                <i class="material-icons md-48 text-link-color">folder</i>
                                <div class="media-body pl-2">
                                    <h3 class="mb-0 text"><?php echo e(DashboardController::getAllRetirementCount(Auth::user()->id)); ?></h3>
                                    <span>Total Retirements</span>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                        <div class="card p-2 pl-3 pr-3">
                            <div class="media justify-items-center align-items-center h-md-100">
                                <i class="material-icons text-link-color md-48">folder</i>
                                <div class="media-body pl-2">
                                    <h4 class="m-0"><?php echo e(DashboardController::getAllExpenseRetirementCount(Auth::user()->id)); ?></h4>
                                    <span>Expense Retirements</span>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                        <div class="card p-2 pl-3 pr-3">
                            <div class="media justify-items-center align-items-center h-md-100">
                                <i class="material-icons text-success md-48">check_circle</i>
                                <div class="media-body pl-2">
                                    <h4 class="m-0"><?php echo e(DashboardController::getAllPaidRequisitionCount(Auth::user()->id)); ?></h4>
                                    <span>Paid Requisitions</span>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>

                        <div class="card p-2 pl-3 pr-3">
                            <div class="media justify-items-center align-items-center h-md-100">
                                <i class="material-icons text-success md-48">check_circle</i>
                                <div class="media-body pl-2">
                                    <h4 class="m-0"><?php echo e(DashboardController::getAllRetiredRequisitionCount(Auth::user()->id)); ?></h4>
                                    <span>Retired Requisitions</span>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>