<link href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">
<script src="https://unpkg.com/sweetalert2@7.18.0/dist/sweetalert2.all.js"></script>
<link rel="icon" href="<?php echo e(url('assets/images/expense.png')); ?>">
<link type="text/css" href="<?php echo e(url('assets/css/themes/default/vendor-morris.css')); ?>" rel="stylesheet">
<link type="text/css" href="<?php echo e(url('assets/css/themes/default/vendor-bootstrap-datepicker.css')); ?>" rel="stylesheet">

<!-- <link rel=”stylesheet” href=” https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">
 -->
<!-- Prevent the demo from appearing in search engines -->
<meta name="robots" content="noindex">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<!-- Simplebar -->
<link type="text/css" href="<?php echo e(url('assets/vendor/simplebar.css')); ?>" rel="stylesheet">

<!-- App CSS -->
<link type="text/css" href="<?php echo e(url('assets/css/themes/default/app.css')); ?>" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="<?php echo e(url('css/bootstrap-confirm-delete.css')); ?>">

<link type="text/css" href="<?php echo e(url('assets/css/themes/default/vendor-bootstrap-datatables.css')); ?>" rel="stylesheet">

