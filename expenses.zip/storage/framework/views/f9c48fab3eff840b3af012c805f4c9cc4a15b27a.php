<?php

use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Accounts\AccountController;

?>


<?php $__env->startSection('content'); ?>

<div class="mdk-drawer-layout js-mdk-drawer-layout mydata" data-fullbleed data-push data-has-scrolling-region>
    <div class="mdk-drawer-layout__content mdk-header-layout__content--scrollable">

        <div class="container">


            <div class="row">
                <div class="col-lg-12">
                    <div class="card card-earnings">
                        <div class="card-header bg-faded">
                            <div class="row align-items-center">
                                <div class="col-lg-12">
                                    <h4 class="card-title">Accounts</h4>
                                     <a href="#" class="float-right btn btn-primary" data-toggle="modal" data-target="#add_items">Add Account</a>
                                </div>
                            </div>
                        </div>
                        <table class="table table-sm  mb-0">
                                    <thead>
                                        <tr>
                                            <th style="border:none;" scope="col" class="text-center">#ID.</th>
                                            <th style="border:none;" scope="col" class="text-center">Account Type</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                       <?php $__currentLoopData = $accounts_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td style="border:none;" class="align-middle text-center">
                                              <span>
                                                 <i class="material-icons delete-row md-10 align-middle mb-1 text-primary">subdirectory_arrow_right</i>
                                              </span>
                                            </td>
                                            <td style="border:none;" class="align-middle text-center font-weight-bold"><?php echo e($type->account_type_name); ?></td>
                                        </tr>


                                           <?php $__currentLoopData = AccountController::get_sub_account_type_by_account_type_id($type->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_account_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <tr>
                                                <td style="border:none;"></td>
                                                <td style="border:none;" class="align-middle text-center">
                                                  <span>
                                                     <i class="material-icons delete-row md-10 align-middle mb-1 text-primary">subdirectory_arrow_right</i>
                                                  </span>
                                                </td>
                                                <td style="border:none;" class="align-middle text-center"><?php echo e($sub_account_type->account_subtype_name); ?></td>
                                            <!-- </tr>
                                            <tr> -->
                                            <!-- <td></td>
                                            <td></td> -->
	                                    		<th scope="col" class="text-center">#Account No.</th>

	                                    		<th scope="col" class="text-center">Account</th>
                                    		</tr>
                                            <tr>
                                           		  <td></td>
                                           		  <td></td>

                                                <td style="border:none;" class="align-middle text-center">

                                                </td>
                                                <?php $__currentLoopData = AccountController::get_accounts_by_account_subtype_id($sub_account_type->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <td  class="align-middle text-center text-success font-weight-bold">
                                                  <span>
                                                     <i class="material-icons delete-row md-10 align-middle mb-1 text-primary">subdirectory_arrow_right</i>
                                                  </span>
                                                  <?php echo e($account->account_no); ?></td>
                                                <td  class="align-middle text-center text-success font-weight-bold"><?php echo e($account->account_name); ?></td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>

<div class="modal fade" id="add_items" tabindex="-1" role="dialog" aria-labelledby="largeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                    <h5 class="modal-title" id="largeModalLabel">Add Account</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
            </div>
            <div class="modal-body">
                  <form method="POST" action="<?php echo e(route('accounts.store')); ?>">
                        <?php echo csrf_field(); ?>
                       	<div class="row">
                       		<div class="col-lg-4">
                       			<div class="form-group">
                       				<input type="text" class="form-control" placeholder="Account No" name="account_no">
                       			</div>
                       		</div>
                       		<div class="col-lg-4">
                       			<div class="form-group">
		                   			<input type="text" class="form-control" placeholder="Account Name" name="account_name">
                       			</div>
                       		</div>
                       		<div class="col-lg-4">
                       			<div class="form-group">
	                       			<select name="sub_accounts_types" class="form-control">
                       					<option value="Select Sub Account Type">Select Sub Account Type</option>
                       					<?php $__currentLoopData = $sub_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       						<option value="<?php echo e($type->id); ?>"><?php echo e($type->account_subtype_name); ?></option>
                       					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       				</select>
                       			</div>

                       		</div>
                       	</div>
                       	<input type="hidden" name="user_id" value="">
                       	<div class="row">
                       		<div class="col-lg-12">
                       			<div class="form-group">
	                      			<textarea class="form-control" col="90" name="description" placeholder="Description"></textarea>
                       			</div>
                       		</div>
                       	</div>
                        <button type="submit" class="btn btn-sm btn-primary">Add Account</button>
                    </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-white" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>